function openPopup(id) {
	document.getElementById(id).style.display = "block";
}

function closePopup(id) {
	document.getElementById(id).style.display = "";
}